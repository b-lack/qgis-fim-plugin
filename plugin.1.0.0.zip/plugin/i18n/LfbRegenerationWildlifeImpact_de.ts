<!DOCTYPE TS><TS>
<context>
    <name>QPushButton</name>
    <message>
        <source>Hello world!</source>
        <translation>HAllo Welt</translation>
    </message>
    <message>
        <source>Hello world!</source>
        <translation>HAllo Welt</translation>
    </message>
</context>
<context>
    <name>TextLabels</name>
    <message>
        <source>lfbLabel1</source>
        <translation>Das nen Label</translation>
    </message>
</context>
</TS>